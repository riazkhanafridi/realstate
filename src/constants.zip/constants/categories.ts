export const categories = {
  electronics: "Electronics",
  chinaSet: "china set",
  luxurious: "luxurious",
  dinnerSet: "dinner set",
  classic: "classic set",
  giftware: "giftware set",
  Electroplating: "giftware set",
  crockery: "crockery",
  cookware: "cookware",
};
